# Running Locally

```bash
npm install --arch=x64 --platform=linux --target=16x sharp
```
